﻿<?php

echo "{success:false,errors:[{id:'login-pwd',msg:'Sorry, you have to type the magic word!'}]}";

?>